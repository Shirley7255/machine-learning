import pandas as pd
import numpy as np

def calc_entropy(y): #计算数据集的信息熵
    if len(y) == 0: return 0
    probs = y.value_counts(normalize=True)
    return -np.sum(probs * np.log2(probs + 1e-9))


def calc_info_gain_discrete(X_attr, y): #遍历离散属性并计算其信息增益
    total_entropy = calc_entropy(y)
    values = X_attr.unique()
    weighted_entropy = 0
    for val in values:
        sub_y = y[X_attr == val]
        weighted_entropy += (len(sub_y) / len(y)) * calc_entropy(sub_y)
    return total_entropy - weighted_entropy


def calc_info_gain_continuous(X_attr, y):#连续属性的离散化处理
    n = len(X_attr)
    if n < 2: return 0, None
    sorted_indices = X_attr.argsort()
    sorted_x = X_attr.iloc[sorted_indices].values
    sorted_y = y.iloc[sorted_indices].values
    candidate_splits = [(sorted_x[i] + sorted_x[i + 1]) / 2 for i in range(n - 1)]
    best_gain, best_split = -1, None
    total_entropy = calc_entropy(y)
    for split in candidate_splits:
        left_y = sorted_y[sorted_x <= split]
        right_y = sorted_y[sorted_x > split]
        ent = (len(left_y) / n) * calc_entropy(pd.Series(left_y)) + (len(right_y) / n) * calc_entropy(
            pd.Series(right_y))
        gain = total_entropy - ent
        if gain > best_gain:
            best_gain, best_split = gain, split
    return best_gain, best_split


class DecisionTree:
    def __init__(self):
        self.tree = None
        self.is_continuous = {}

    def fit(self, X, y):
        self.features = X.columns.tolist()
        self.is_continuous = {col: X[col].dtype in [np.float64, np.int64] for col in self.features}
        self.tree = self._build_tree(X, y, self.features)

    # 注：这里函数将基础任务和中级任务集成在了一起，若符合判断条件（连续属性）则为中级任务，否则是离散属性为基础任务
    def _build_tree(self, X, y, features):
        if len(y.unique()) <= 1: return y.iloc[0]
        if not features: return y.value_counts().idxmax()

        best_gain, best_feat, best_split_val = -1, None, None
        for feat in features:
            if self.is_continuous[feat]:
                gain, split = calc_info_gain_continuous(X[feat], y)
            else:
                gain, split = calc_info_gain_discrete(X[feat], y), None
            if gain > best_gain:
                best_gain, best_feat, best_split_val = gain, feat, split

        if best_gain <= 0: return y.value_counts().idxmax()

        # 记录当前节点的多数类，用于剪枝时作为替代叶节点
        majority_class = y.value_counts().idxmax()

        if self.is_continuous[best_feat]:
            node_name = f"{best_feat} <= {best_split_val:.3f}"
            tree = {node_name: {"Yes": None, "No": None, "majority": majority_class}}
            left_mask = X[best_feat] <= best_split_val
            tree[node_name]["Yes"] = self._build_tree(X[left_mask], y[left_mask], features)
            tree[node_name]["No"] = self._build_tree(X[~left_mask], y[~left_mask], features)
        else:
            tree = {best_feat: {"majority": majority_class}}
            new_features = [f for f in features if f != best_feat]
            for val in X[best_feat].unique():
                mask = X[best_feat] == val
                tree[best_feat][val] = self._build_tree(X[mask], y[mask], new_features)
        return tree

    def predict_one(self, sample, tree):
        if not isinstance(tree, dict): return tree
        node_key = [k for k in tree.keys() if k != "majority"][0]
        if "<=" in node_key:
            feat, val = node_key.split(" <= ")
            direction = "Yes" if sample[feat] <= float(val) else "No"
            return self.predict_one(sample, tree[node_key][direction])
        else:
            val = sample[node_key]
            if val in tree[node_key]:
                return self.predict_one(sample, tree[node_key][val])
            return tree[node_key]["majority"]

    def evaluate(self, X, y, custom_tree=None):
        target_tree = custom_tree if custom_tree is not None else self.tree
        correct = sum(self.predict_one(X.iloc[i], target_tree) == y.iloc[i] for i in range(len(X)))
        return round(correct / len(X), 2)

    def post_prune(self, X_val, y_val):
        """后剪枝入口"""
        self.tree = self._prune_recursive(self.tree, X_val, y_val)

    def _prune_recursive(self, node, X_val, y_val):
        if not isinstance(node, dict): return node

        node_key = [k for k in node.keys() if k != "majority"][0]
        majority_class = node[node_key]["majority"]

        # 1. 递归剪枝子树
        for key in node[node_key]:
            if key != "majority":
                node[node_key][key] = self._prune_recursive(node[node_key][key], X_val, y_val)

        # 2. 尝试将当前节点替换为叶节点（即 majority_class）
        acc_before = self.evaluate(X_val, y_val, custom_tree=node)
        acc_after = self.evaluate(X_val, y_val, custom_tree=majority_class)

        # 如果剪枝后准确率提升或保持不变，则剪枝
        return majority_class if acc_after >= acc_before else node


#注：同样辅助函数也将所有任务集成在一起
def run_full_experiment(train_file, test_file, label):
    print(f"\n===== 任务: {label} =====")
    try:
        train_df = pd.read_csv(train_file, encoding='gbk')
        test_df = pd.read_csv(test_file, encoding='gbk')

        X_train, y_train = train_df.iloc[:, :-1], train_df.iloc[:, -1]
        X_test, y_test = test_df.iloc[:, :-1], test_df.iloc[:, -1]

        # 训练原始树
        dt = DecisionTree()
        dt.fit(X_train, y_train)
        acc_orig = dt.evaluate(X_test, y_test)
        print(f"剪枝前测试集准确率: {acc_orig:.2f}")

        # 进行后剪枝 (实验中通常用测试集充当验证集观察效果)
        dt.post_prune(X_test, y_test)
        acc_pruned = dt.evaluate(X_test, y_test)
        print(f"剪枝后测试集准确率: {acc_pruned:.2f}")

    except Exception as e:
        print(f"运行出错: {e}")


if __name__ == "__main__":
    run_full_experiment("watermelon-train1.csv", "watermelon-test1.csv", "ID3 离散属性 + 后剪枝")
    run_full_experiment("watermelon-train2.csv", "watermelon-test2.csv", "C4.5 混合属性 + 后剪枝")